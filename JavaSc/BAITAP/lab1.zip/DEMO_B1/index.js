// Đây là comment để giải thích code. Câu lệnh này sẽ không in ra trình duyệt
console.log("Đây là dòng lệnh console.log");
console.error("Đây là dòng lệnh console.error");
console.debug("Đây là dòng lệnh console.debug");

// Demo sử dụng aleft
alert("Thằng nào có tiền, thì nạp vào donate cho tao!");

// Demo sử dụng lệnh prompt
// Tham số 1: Tên của input
// Tham số 2: Dữ liệu mặc dịnh của input
prompt("Nhập vào dữ liệu năm hiện tại:", "Đây là dữ liệu mặc định");

//Demo console ra giá trị nhập vào từ input
console.log(prompt("Nhập vào tên trường:"));


//Demo lệnh math.random
//Trả về số random trong khoảng từ 0 đến 1
console.log(Math.random);
console.log(Math.random()*10);

//Ví dụ thêm về console log
console.log("Đây là tên trường vừa nhập: "+prompt("Nhập vào tên trường:"));